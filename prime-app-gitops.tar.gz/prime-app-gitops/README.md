# Prime Series and Movies — GitOps repo

Three-tier web app on OpenShift user-defined networks, packaged as one Helm chart and
deployed by Argo CD (OpenShift GitOps) from GitLab.

```
Browser ─► Route prime-series-movies ─► frontend-web (webapp-frontend)
                                          │  nginx /api ─► frontend-backend-net (192.168.50.0/24)
                                          ▼
                                        backend-api ×2 (webapp-backend)   webapp-cudn 10.50.0.0/16
                                          │  webapp-db.webapp-database.svc:3306
                                          ▼  (NetworkPolicy: only app=backend-api)
                                        MariaDB StatefulSet (webapp-database)
```

## Layout

```
charts/prime-app/          Helm chart
  values.yaml              images, namespaces, networks, credentials, route
  files/                   app code and config, loaded into ConfigMaps
  templates/platform/      namespaces (UDN labels) + the two ClusterUserDefinedNetworks
  templates/database/      MariaDB StatefulSet, Services, Secret, NetworkPolicy
  templates/backend/       Python API Deployment, Service, Secret, config
  templates/frontend/      nginx Deployment + upstream-sync sidecar, RBAC, Service, Route
argocd/                    rbac.yaml, repository.yaml, application.yaml
scripts/verify-tiers.sh    checks every tier and network path (PASS/FAIL)
.gitlab-ci.yml             helm lint + template on every push
```

Argo CD sync waves create things in order: namespaces (-3) → networks (-2) →
database (0) → backend (1) → frontend (2). Each wave waits for the previous one to be
healthy; the database only reports ready once its tables exist.

The frontend reaches the backend through pod IPs on the secondary network, which no
Service covers. The **upstream-sync** sidecar watches the backend pods and reloads nginx
when their IPs change, so there is no manual step after a sync or a backend restart.

## Deploy

1. **Push this repo to GitLab** (project `prime-app`, branch `main`).
2. **Create a deploy token** in GitLab: *Settings → Repository → Deploy tokens*, scope
   `read_repository`.
3. **Give Argo CD access** (once, as cluster-admin):
   ```bash
   # fill in URL, token user and token first
   oc apply -f argocd/repository.yaml
   oc apply -f argocd/rbac.yaml
   ```
4. **Create the Application:**
   ```bash
   oc apply -f argocd/application.yaml
   oc get application prime-app -n openshift-gitops -w     # Synced / Healthy
   ```
5. **Verify:** `./scripts/verify-tiers.sh`

Optional: add a GitLab webhook to Argo CD (`https://<argocd-route>/api/webhook`, push
events) so pushes sync immediately instead of on the ~3-minute poll.

## Change something

Edit, commit, push to `main`; Argo CD applies it. Examples:
- more backend replicas: `backend.replicas` in `values.yaml`
- HTTPS for the site: `frontend.route.tls.enabled: true`
- site or API code: edit `files/frontend/*` or `files/backend/app.py` (pods restart
  automatically via checksum annotations where needed)

## Credentials

`values.yaml` holds lab passwords so the chart works out of the box. For anything real,
create the two Secrets yourself (Sealed Secrets, External Secrets, Vault…) and set
`database.existingSecret` and `backend.existingSecret`; the chart then creates none.

## Safety

Namespaces and ClusterUserDefinedNetworks are marked `Prune=false,Delete=false`: removing
them from Git or deleting the Application never deletes them (or the database volume in
them). The MariaDB data lives on PVC `data-webapp-db-0`.
