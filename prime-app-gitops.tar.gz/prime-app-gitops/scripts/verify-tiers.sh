#!/bin/bash
# verify-tiers.sh - check the three-tier layout of Prime Series and Movies:
#   frontend : webapp-frontend, reachable from outside through its Route
#   backend  : webapp-backend, reachable by the frontend only over frontend-backend-net
#   database : webapp-database on webapp-cudn, reachable only by app=backend-api pods
set -uo pipefail
FRONT_NS=webapp-frontend; BACK_NS=webapp-backend; DB_NS=webapp-database
PY_IMAGE=registry.access.redhat.com/ubi9/python-311:latest
PASS=0; FAIL=0
pass() { printf '  \e[32mPASS\e[0m  %s\n' "$*"; PASS=$((PASS+1)); }
fail() { printf '  \e[31mFAIL\e[0m  %s\n' "$*"; FAIL=$((FAIL+1)); }
check() { if [ "$1" = yes ]; then pass "$2"; else fail "$2${3:+  ($3)}"; fi; }
section() { printf '\n== %s\n' "$*"; }

# Print "interface ip" for every network of a pod, from its network-status annotation
ifaces() {
  oc get pod "$2" -n "$1" -o json | python3 -c '
import json, sys
pod = json.load(sys.stdin)
for n in json.loads(pod["metadata"].get("annotations", {}).get("k8s.v1.cni.cncf.io/network-status", "[]")):
    for ip in n.get("ips", []):
        print(n.get("interface", "?"), ip, n.get("name", ""))'
}
# Run a TCP connect test from a pod: prints OPEN or BLOCKED
tcp_from_pod() {  # ns pod host port
  oc exec -n "$1" "$2" -- timeout 4 bash -c "</dev/tcp/$3/$4" >/dev/null 2>&1 && echo OPEN || echo BLOCKED
}

F=$(oc get pod -n $FRONT_NS -l app=frontend-web --field-selector=status.phase=Running -o name | head -1 | cut -d/ -f2)
B=$(oc get pod -n $BACK_NS -l app=backend-api --field-selector=status.phase=Running -o name | head -1 | cut -d/ -f2)
D=$(oc get pod -n $DB_NS -l app=webapp-db --field-selector=status.phase=Running -o name | head -1 | cut -d/ -f2)
for v in F B D; do [ -n "${!v}" ] || { echo "No running pod found for $v - are all three tiers deployed?"; exit 1; }; done

F_NET1=$(ifaces $FRONT_NS "$F" | awk '$1=="net1"{print $2}' | cut -d/ -f1)
B_NET1=$(ifaces $BACK_NS "$B" | awk '$1=="net1"{print $2}' | cut -d/ -f1)
B_UDN=$(ifaces $BACK_NS "$B" | awk '$1=="ovn-udn1"{print $2}' | cut -d/ -f1)
D_UDN=$(ifaces $DB_NS "$D" | awk '$1=="ovn-udn1"{print $2}' | cut -d/ -f1)

# ---------------------------------------------------------------------------
section "Frontend: webapp-frontend, reachable from outside through its Route"
# Route that points at the frontend-web Service, whatever it is named (override: ROUTE=name)
ROUTE=${ROUTE:-$(oc get route -n "$FRONT_NS" -o jsonpath='{range .items[?(@.spec.to.name=="frontend-web")]}{.metadata.name}{"\n"}{end}' 2>/dev/null | head -1)}
HOST=$(oc get route "$ROUTE" -n "$FRONT_NS" -o jsonpath='{.spec.host}' 2>/dev/null || true)
check "$([ -n "$HOST" ] && echo yes)" "Route ${ROUTE:-<none>} -> Service frontend-web exists: ${HOST:-none}"
PAGE=$(curl -s --max-time 10 "http://$HOST/" 2>/dev/null)
check "$(echo "$PAGE" | grep -q 'You are connected to the Frontend' && echo yes)" "Site answers from outside the cluster (http://$HOST/)"
check "$([ -n "$F_NET1" ] && echo yes)" "Frontend pod has a frontend-backend-net interface (net1: ${F_NET1:-none})"

# ---------------------------------------------------------------------------
section "Backend: webapp-backend, reached by the frontend only over frontend-backend-net"
check "$([ -z "$(oc get route -n $BACK_NS -o name 2>/dev/null)" ] && echo yes)" "Backend has no Route (not exposed outside the cluster)"
check "$([[ "$B_UDN" == 10.50.* ]] && echo yes)" "Backend primary network is webapp-cudn (ovn-udn1: ${B_UDN:-none})"
check "$([ -n "$B_NET1" ] && echo yes)" "Backend has a frontend-backend-net interface (net1: ${B_NET1:-none})"
R=$(oc exec -n $FRONT_NS "$F" -- curl -s --max-time 4 "http://$B_NET1:8080/healthz" 2>/dev/null)
check "$(echo "$R" | grep -q '"ok"' && echo yes)" "Frontend -> backend over frontend-backend-net ($B_NET1:8080) works"
R=$(tcp_from_pod $FRONT_NS "$F" backend-api.$BACK_NS.svc 8080)
check "$([ "$R" = BLOCKED ] && echo yes)" "Frontend -> backend Service (default network path) is blocked" "$R"
R=$(tcp_from_pod $FRONT_NS "$F" "$B_UDN" 8080)
check "$([ "$R" = BLOCKED ] && echo yes)" "Frontend -> backend webapp-cudn IP ($B_UDN) is blocked" "$R"
H=$(curl -s --max-time 10 "http://$HOST/api/health" 2>/dev/null)
check "$(echo "$H" | grep -q '"database": "up"' && echo yes)" "Browser path /api -> frontend nginx -> backend -> database works" "$H"

# ---------------------------------------------------------------------------
section "Database: webapp-database on webapp-cudn, reachable only by the backend"
check "$([[ "$D_UDN" == 10.50.* ]] && echo yes)" "Database primary network is webapp-cudn (ovn-udn1: ${D_UDN:-none})"
check "$(oc get networkpolicy restrict-db-access -n $DB_NS >/dev/null 2>&1 && echo yes)" "NetworkPolicy restrict-db-access exists"
R=$(oc exec -n $BACK_NS "$B" -- python3 -c "import socket; socket.create_connection(('webapp-db.$DB_NS.svc',3306),4); print('OPEN')" 2>/dev/null)
check "$([ "$R" = OPEN ] && echo yes)" "Backend (app=backend-api) -> database:3306 works" "${R:-BLOCKED}"
R=$(tcp_from_pod $FRONT_NS "$F" webapp-db.$DB_NS.svc 3306)
check "$([ "$R" = BLOCKED ] && echo yes)" "Frontend -> database is blocked (not on webapp-cudn)" "$R"

echo "  ...starting two short-lived test pods in $BACK_NS (same network as the backend)"
probe() {  # name labels
  oc run "$1" -n $BACK_NS --image=$PY_IMAGE --restart=Never --rm -i --quiet --labels="$2" --command -- \
    python3 -c "
import socket
try:
    socket.create_connection(('webapp-db.$DB_NS.svc', 3306), 4); print('RESULT=OPEN')
except Exception:
    print('RESULT=BLOCKED')" 2>/dev/null | grep -o 'RESULT=[A-Z]*' | cut -d= -f2
}
R=$(probe dbprobe-other app=something-else)
check "$([ "$R" = BLOCKED ] && echo yes)" "Other pod on webapp-cudn (app=something-else) -> database is blocked by the policy" "${R:-no result}"
R=$(probe dbprobe-backend app=backend-api)
check "$([ "$R" = OPEN ] && echo yes)" "Same test pod labelled app=backend-api -> database works (the label is what the policy allows)" "${R:-no result}"

printf '\n%d passed, %d failed\n' "$PASS" "$FAIL"
[ "$FAIL" -eq 0 ]
