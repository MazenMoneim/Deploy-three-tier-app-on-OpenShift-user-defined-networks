{{/* Common labels for every object */}}
{{- define "prime.labels" -}}
app.kubernetes.io/part-of: {{ .Chart.Name }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/instance: {{ .Release.Name }}
helm.sh/chart: {{ printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" }}
{{- end }}

{{/* Labels for one component: (dict "ctx" $ "app" "backend-api" "component" "backend") */}}
{{- define "prime.componentLabels" -}}
{{ include "prime.labels" .ctx }}
app: {{ .app }}
app.kubernetes.io/name: {{ .app }}
app.kubernetes.io/component: {{ .component }}
{{- end }}

{{/* Argo CD sync wave annotation */}}
{{- define "prime.wave" -}}
argocd.argoproj.io/sync-wave: {{ . | quote }}
{{- end }}

{{- define "prime.dbSecretName" -}}
{{- .Values.database.existingSecret | default "webapp-db-credentials" -}}
{{- end }}

{{- define "prime.backendSecretName" -}}
{{- .Values.backend.existingSecret | default "backend-db-credentials" -}}
{{- end }}

{{- define "prime.dbHost" -}}
webapp-db.{{ .Values.namespaces.database }}.svc.cluster.local
{{- end }}

{{/* upstream-sync environment (init container and sidecar) */}}
{{- define "prime.syncEnv" -}}
- name: BACKEND_NAMESPACE
  value: {{ .Values.namespaces.backend }}
- name: BACKEND_SELECTOR
  value: app=backend-api
- name: NETWORK_NAME
  value: {{ .Values.networks.secondary.name }}
- name: BACKEND_PORT
  value: "8080"
- name: UPSTREAM_FILE
  value: /etc/nginx/prime/upstream.conf
- name: NGINX_PID_FILE
  value: /etc/nginx/prime/nginx.pid
- name: INTERVAL
  value: {{ .Values.frontend.upstreamSync.intervalSeconds | quote }}
- name: PYTHONUNBUFFERED
  value: "1"
{{- end }}

{{/* restricted-v2 friendly container securityContext */}}
{{- define "prime.restrictedContainer" -}}
securityContext:
  allowPrivilegeEscalation: false
  runAsNonRoot: true
  capabilities:
    drop: ["ALL"]
  seccompProfile:
    type: RuntimeDefault
{{- end }}
