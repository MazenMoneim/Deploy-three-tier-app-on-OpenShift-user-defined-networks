#!/usr/bin/env python3
"""Prime Series and Movies - backend API.

Standard library HTTP server + PyMySQL (pure Python, loaded from the wheel on PYTHONPATH).

  GET    /healthz                 process is up (liveness/readiness)
  GET    /api/health              backend + database status
  GET    /api/titles[?kind=&q=]   catalogue (kind: movie|series, q: search text)
  GET    /api/titles/<id>         one title
  GET    /api/watchlist           saved title ids for the viewer (X-Viewer-Id header)
  PUT    /api/watchlist/<id>      save a title for the viewer
  DELETE /api/watchlist/<id>      remove a title for the viewer
"""
import json
import logging
import os
import re
import signal
import sys
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

import pymysql

logging.basicConfig(level=os.environ.get("LOG_LEVEL", "INFO"), stream=sys.stdout,
                    format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("backend")

DB = dict(
    host=os.environ.get("DB_HOST", "webapp-db"),
    port=int(os.environ.get("DB_PORT", "3306")),
    user=os.environ.get("DB_USER", "primeapp"),
    password=os.environ.get("DB_PASSWORD", ""),
    database=os.environ.get("DB_NAME", "primedb"),
    charset="utf8mb4",
    connect_timeout=3, read_timeout=5, write_timeout=5,
    autocommit=True,
    cursorclass=pymysql.cursors.DictCursor,
)
PORT = int(os.environ.get("PORT", "8080"))
CORS_ORIGIN = os.environ.get("CORS_ORIGIN", "*")
VIEWER_RE = re.compile(r"^[A-Za-z0-9-]{8,64}$")
COLUMNS = "id, kind, title, year, rating, minutes, seasons, genres, plot"


class HttpError(Exception):
    def __init__(self, status, message):
        super().__init__(message)
        self.status, self.message = status, message


def query(sql, args=None):
    conn = pymysql.connect(**DB)
    try:
        with conn.cursor() as cur:
            cur.execute(sql, args)
            return cur.fetchall()
    finally:
        conn.close()


def to_title(row):
    return {
        "id": row["id"], "kind": row["kind"], "title": row["title"], "year": row["year"],
        "rating": float(row["rating"]), "mins": row["minutes"], "seasons": row["seasons"],
        "genres": [g.strip() for g in row["genres"].split(",") if g.strip()], "plot": row["plot"],
    }


class Handler(BaseHTTPRequestHandler):
    server_version = "PrimeBackend/1.0"
    protocol_version = "HTTP/1.1"

    # ---- plumbing -----------------------------------------------------------
    def send_json(self, status, body=None):
        data = b"" if body is None else json.dumps(body).encode()
        self.send_response(status)
        self.send_header("Access-Control-Allow-Origin", CORS_ORIGIN)
        self.send_header("Access-Control-Allow-Methods", "GET, PUT, DELETE, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, X-Viewer-Id")
        self.send_header("Access-Control-Max-Age", "600")
        self.send_header("Cache-Control", "no-store")
        if body is not None:
            self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        if data and self.command != "HEAD":
            self.wfile.write(data)

    def dispatch(self, routes):
        url = urlparse(self.path)
        try:
            for pattern, fn in routes:
                m = re.fullmatch(pattern, url.path.rstrip("/") or "/")
                if m:
                    return fn(parse_qs(url.query), *m.groups())
            raise HttpError(404, "No such endpoint")
        except HttpError as e:
            self.send_json(e.status, {"error": e.message})
        except pymysql.MySQLError as e:
            log.error("database error: %s", e)
            self.send_json(503, {"error": "Database unavailable", "detail": str(e)})
        except Exception:
            log.exception("unhandled error")
            self.send_json(500, {"error": "Internal server error"})

    def viewer(self):
        v = self.headers.get("X-Viewer-Id", "")
        if not VIEWER_RE.match(v):
            raise HttpError(400, "Send an X-Viewer-Id header (8-64 letters, digits or dashes)")
        return v

    def log_message(self, fmt, *args):
        if self.path != "/healthz":
            log.info("%s %s", self.address_string(), fmt % args)

    # ---- verbs ----------------------------------------------------------------
    def do_OPTIONS(self):
        self.send_json(204)

    def do_GET(self):
        self.dispatch([
            (r"/healthz", lambda q: self.send_json(200, {"status": "ok"})),
            (r"/api/health", self.health),
            (r"/api/titles", self.list_titles),
            (r"/api/titles/(\d+)", self.get_title),
            (r"/api/watchlist", self.get_watchlist),
        ])

    def do_PUT(self):
        self.dispatch([(r"/api/watchlist/(\d+)", self.add_watch)])

    def do_DELETE(self):
        self.dispatch([(r"/api/watchlist/(\d+)", self.remove_watch)])

    # ---- handlers -------------------------------------------------------------
    def health(self, q):
        try:
            row = query("SELECT VERSION() AS version, (SELECT COUNT(*) FROM titles) AS titles")[0]
            self.send_json(200, {"status": "ok", "database": "up", "db_host": DB["host"],
                                 "db_version": row["version"], "titles": row["titles"]})
        except pymysql.MySQLError as e:
            self.send_json(503, {"status": "degraded", "database": "down", "db_host": DB["host"], "detail": str(e)})

    def list_titles(self, q):
        sql, args = f"SELECT {COLUMNS} FROM titles WHERE 1=1", []
        kind = q.get("kind", [""])[0]
        if kind:
            if kind not in ("movie", "series"):
                raise HttpError(400, "kind must be movie or series")
            sql += " AND kind = %s"
            args.append(kind)
        text = q.get("q", [""])[0].strip()
        if text:
            sql += " AND (title LIKE %s OR genres LIKE %s)"
            args += [f"%{text}%"] * 2
        sql += " ORDER BY rating DESC, year DESC"
        self.send_json(200, [to_title(r) for r in query(sql, args)])

    def get_title(self, q, tid):
        rows = query(f"SELECT {COLUMNS} FROM titles WHERE id = %s", (int(tid),))
        if not rows:
            raise HttpError(404, f"Title {tid} not found")
        self.send_json(200, to_title(rows[0]))

    def get_watchlist(self, q):
        rows = query("SELECT title_id FROM watchlist WHERE viewer_id = %s ORDER BY added_at", (self.viewer(),))
        self.send_json(200, [r["title_id"] for r in rows])

    def add_watch(self, q, tid):
        viewer = self.viewer()
        try:
            query("INSERT INTO watchlist (viewer_id, title_id) VALUES (%s, %s) "
                  "ON DUPLICATE KEY UPDATE added_at = added_at", (viewer, int(tid)))
        except pymysql.err.IntegrityError:
            raise HttpError(404, f"Title {tid} not found")
        self.send_json(204)

    def remove_watch(self, q, tid):
        query("DELETE FROM watchlist WHERE viewer_id = %s AND title_id = %s", (self.viewer(), int(tid)))
        self.send_json(204)


def main():
    server = ThreadingHTTPServer(("0.0.0.0", PORT), Handler)
    server.daemon_threads = True
    signal.signal(signal.SIGTERM, lambda *_: (log.info("SIGTERM, shutting down"), sys.exit(0)))
    log.info("listening on :%d, database %s@%s:%s/%s", PORT, DB["user"], DB["host"], DB["port"], DB["database"])
    server.serve_forever()


if __name__ == "__main__":
    main()
