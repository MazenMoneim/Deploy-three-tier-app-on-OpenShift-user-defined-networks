(function () {
  "use strict";

  // Built-in catalogue: shown until the backend answers, and whenever it can't be reached.
  var TITLES = [
    { id: 1,  kind: "movie",  title: "The Salt Road", year: 2025, rating: 8.4, mins: 132, genres: ["Drama", "Adventure"], hues: [28, 350], plot: "A caravan guide agrees to one last crossing of the Western Desert, carrying a passenger who is not what she claims." },
    { id: 2,  kind: "series", title: "Harbor Lights", year: 2024, rating: 8.9, seasons: 3, genres: ["Crime", "Thriller"], hues: [205, 250], plot: "A port inspector in Alexandria follows a missing shipping container into a network that reaches the top of the city." },
    { id: 3,  kind: "movie",  title: "Paper Moons", year: 2023, rating: 7.6, mins: 104, genres: ["Romance", "Comedy"], hues: [320, 20], plot: "Two rival stationery shop owners discover they have been writing to each other anonymously for a year." },
    { id: 4,  kind: "series", title: "Station Nine", year: 2025, rating: 8.2, seasons: 2, genres: ["Sci-Fi", "Mystery"], hues: [180, 230], plot: "The crew of a remote research station wakes up to find six months missing from every log." },
    { id: 5,  kind: "movie",  title: "Quiet Engines", year: 2022, rating: 7.9, mins: 118, genres: ["Drama"], hues: [45, 10], plot: "A retired rally driver teaches his estranged granddaughter to drive across the Delta in a borrowed car." },
    { id: 6,  kind: "series", title: "The Long Shift", year: 2023, rating: 8.6, seasons: 4, genres: ["Drama", "Medical"], hues: [150, 190], plot: "Night-shift doctors at a crowded Cairo hospital hold their lives together between emergencies." },
    { id: 7,  kind: "movie",  title: "Glass Orchard", year: 2024, rating: 7.2, mins: 97, genres: ["Horror"], hues: [95, 280], plot: "A family inherits an orchard where the fruit grows clear, and anyone who eats it remembers something they shouldn't." },
    { id: 8,  kind: "series", title: "Northbound", year: 2022, rating: 7.8, seasons: 1, genres: ["Adventure", "Documentary"], hues: [210, 170], plot: "Six strangers attempt to travel from Aswan to the Arctic Circle without a single flight." },
    { id: 9,  kind: "movie",  title: "Last Call at Zamalek", year: 2025, rating: 8.1, mins: 111, genres: ["Crime", "Drama"], hues: [260, 330], plot: "Over one night in a jazz bar, a bartender pieces together why every regular is lying to the police." },
    { id: 10, kind: "series", title: "Small Kingdoms", year: 2025, rating: 8.0, seasons: 2, genres: ["Comedy"], hues: [55, 100], plot: "Three siblings take over their late father's failing neighborhood bakery and its very loyal, very strange customers." },
    { id: 11, kind: "movie",  title: "Undertow", year: 2021, rating: 7.4, mins: 125, genres: ["Thriller"], hues: [195, 215], plot: "A free-diving instructor finds a sealed case on the Red Sea floor and becomes the only witness to a crime." },
    { id: 12, kind: "series", title: "Kingdom of Ash", year: 2024, rating: 9.1, seasons: 3, genres: ["Fantasy", "Drama"], hues: [8, 38], plot: "When the volcano that protects a mountain realm goes quiet, five houses race to claim what comes next." },
    { id: 13, kind: "movie",  title: "Signal & Noise", year: 2025, rating: 7.7, mins: 101, genres: ["Sci-Fi", "Thriller"], hues: [290, 190], plot: "A network engineer notices one tower broadcasting a message nobody sent — and it's addressed to her." },
    { id: 14, kind: "movie",  title: "The Understudy", year: 2023, rating: 8.3, mins: 115, genres: ["Drama", "Music"], hues: [340, 45], plot: "An opera understudy gets one night on stage and a single chance to prove the star was never irreplaceable." },
    { id: 15, kind: "series", title: "Dead Reckoning", year: 2021, rating: 8.4, seasons: 5, genres: ["Crime", "Mystery"], hues: [220, 0], plot: "A navigator-turned-detective solves cases at sea where every suspect is on board and nobody can leave." },
    { id: 16, kind: "series", title: "Wildflower Season", year: 2025, rating: 7.5, seasons: 1, genres: ["Romance", "Drama"], hues: [120, 330], plot: "A florist returns to her hometown for one spring and finds everything, and everyone, has moved on but her." }
  ];

  var store = {
    get: function () { try { return JSON.parse(localStorage.getItem("psm:list") || "[]"); } catch (e) { return []; } },
    set: function (v) { try { localStorage.setItem("psm:list", JSON.stringify(v)); } catch (e) {} }
  };
  var state = { filter: "all", query: "", list: store.get(), current: null, source: "builtin" };

  // ---- Backend API ---------------------------------------------------------
  // URL comes from config.js; if empty it is derived from this page's route host.
  var cfg = window.PRIME_CONFIG || {};
  var API = (cfg.apiUrl || (location.host.indexOf("frontend-web-webapp-frontend.") === 0
    ? location.protocol + "//" + location.host.replace("frontend-web-webapp-frontend.", "backend-api-webapp-backend.")
    : "")).replace(/\/+$/, "");

  var VIEWER = (function () {
    var id;
    try { id = localStorage.getItem("psm:viewer"); } catch (e) {}
    if (!id) {
      id = (window.crypto && crypto.randomUUID) ? crypto.randomUUID()
        : "v-" + Date.now().toString(36) + "-" + Math.random().toString(36).slice(2, 12);
      try { localStorage.setItem("psm:viewer", id); } catch (e) {}
    }
    return id;
  })();

  function api(method, path) {
    var ctl = window.AbortController ? new AbortController() : null;
    var timer = setTimeout(function () { if (ctl) ctl.abort(); }, 5000);
    return fetch(API + path, { method: method, headers: { "X-Viewer-Id": VIEWER }, signal: ctl && ctl.signal })
      .then(function (r) {
        clearTimeout(timer);
        if (r.status === 204) return null;
        return r.json().then(function (body) {
          if (!r.ok) throw new Error(body && body.error || ("HTTP " + r.status));
          return body;
        });
      }, function (e) { clearTimeout(timer); throw e; });
  }

  function normalize(t) {
    t.hues = t.hues || [(t.id * 47) % 360, (t.id * 47 + 140) % 360];
    t.genres = t.genres || [];
    return t;
  }

  function setBackendStatus(kind, text) {
    var el = $("backend"); el.className = "status backend " + kind; el.lastChild.textContent = text;
  }

  function connectBackend() {
    if (!API) { setBackendStatus("off", "Backend not configured: showing built-in catalogue"); return; }
    setBackendStatus("wait", "Connecting to backend…");
    api("GET", "/api/health").then(function (h) {
      return Promise.all([api("GET", "/api/titles"), api("GET", "/api/watchlist")]).then(function (res) {
        TITLES = res[0].map(normalize);
        var server = res[1], local = state.list.filter(function (id) { return server.indexOf(id) === -1; });
        // Move anything saved in this browser before the backend existed into the database.
        local.forEach(function (id) { api("PUT", "/api/watchlist/" + id).catch(function () {}); });
        state.list = server.concat(local);
        state.source = "api";
        probePhotos(); render();
        setBackendStatus("on", "Backend connected: " + h.titles + " titles from MariaDB " + String(h.db_version).split("-")[0]);
      });
    }).catch(function (e) {
      var down = /Database unavailable|HTTP 503/.test(String(e && e.message));
      setBackendStatus("off", down ? "Backend is up but the database is unreachable: showing built-in catalogue"
                                   : "Backend not reachable: showing built-in catalogue");
    });
  }

  var $ = function (id) { return document.getElementById(id); };
  var esc = function (s) { return String(s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); };

  function facts(t) {
    var len = t.kind === "movie" ? (t.mins ? Math.floor(t.mins / 60) + "h " + (t.mins % 60) + "m" : "")
                                 : (t.seasons ? t.seasons + (t.seasons > 1 ? " seasons" : " season") : "");
    return [t.year, len, t.genres.join(", "), "★ " + t.rating.toFixed(1)].filter(Boolean).join("  |  ");
  }

  // Artwork: built-in illustration, replaced by posters/<id>.jpg when that file exists.
  var photos = {}, probed = {}, rerender;
  function probePhotos() {
    TITLES.forEach(function (t) {
      if (probed[t.id]) return;
      probed[t.id] = true;
      var img = new Image();
      img.onload = function () { photos[t.id] = true; clearTimeout(rerender); rerender = setTimeout(render, 50); };
      img.src = "posters/" + t.id + ".jpg";
    });
  }
  probePhotos();

  function poster(t, big) {
    return '<div class="poster">' + window.posterArt(t) +
      (photos[t.id] ? '<img class="p-photo" src="posters/' + t.id + '.jpg" alt="">' : "") +
      (big ? "" : '<span class="rating">★ ' + t.rating.toFixed(1) + "</span>") +
      '<span class="p-year">' + t.year + (t.kind === "series" ? " series" : " film") + "</span>" +
      '<span class="p-title">' + esc(t.title) + "</span></div>";
  }

  function card(t) {
    return '<button class="card" data-id="' + t.id + '" aria-label="' + esc(t.title) + ", " + t.kind + '">' +
      poster(t) + '<div class="meta">' + t.genres.join(", ") + "</div></button>";
  }

  function matches(t) {
    var q = state.query;
    if (!q) return true;
    return (t.title + " " + t.genres.join(" ") + " " + t.kind).toLowerCase().indexOf(q) !== -1;
  }

  // Home: site name over a wall of posters. Movies/Series tabs: the top-rated title.
  function renderHomeHero() {
    var order = TITLES.slice().sort(function (a, b) { return (a.id * 7) % 16 - (b.id * 7) % 16; });
    var wall = order.concat(order).slice(0, 30).map(function (t) { return poster(t, true); }).join("");
    $("hero").hidden = false;
    $("hero").className = "hero hero-home";
    $("hero").innerHTML =
      '<div class="wall" aria-hidden="true"><div class="wall-track">' + wall + wall + "</div></div>" +
      '<div class="hero-content">' +
        "<h1>Prime Series and Movies</h1>" +
        '<p class="plot">Browse films and series, open any title for the story, and save the ones you want to watch to your list.</p>' +
        '<div class="actions"><button class="btn primary" data-goto="movie">Browse movies</button>' +
        '<button class="btn" data-goto="series">Browse series</button></div>' +
      "</div>";
  }

  function renderHero(t) {
    if (!t) { $("hero").hidden = true; return; }
    $("hero").hidden = false;
    $("hero").className = "hero";
    $("hero").innerHTML =
      '<div class="hero-bg">' + poster(t, true) + "</div>" +
      '<div class="hero-content">' +
        '<span class="kind ' + t.kind + '">' + (t.kind === "series" ? "Series" : "Movie") + "</span>" +
        "<h1>" + esc(t.title) + "</h1>" +
        '<p class="facts">' + facts(t) + "</p>" +
        '<p class="plot">' + esc(t.plot) + "</p>" +
        '<div class="actions"><button class="btn primary" data-play="' + t.id + '">Play trailer</button>' +
        '<button class="btn" data-id="' + t.id + '">More info</button></div>' +
      "</div>";
  }

  function shelf(title, items, asGrid) {
    if (!items.length) return "";
    return '<section class="shelf"><h2>' + title + '</h2><div class="' + (asGrid ? "grid" : "row") + '">' + items.map(card).join("") + "</div></section>";
  }

  function render() {
    var pool = TITLES.filter(matches);
    var html = "";
    var byRating = function (a, b) { return b.rating - a.rating; };
    var byYear = function (a, b) { return b.year - a.year || b.rating - a.rating; };

    if (state.filter === "list") {
      pool = pool.filter(function (t) { return state.list.indexOf(t.id) !== -1; });
      renderHero(null);
      html = shelf("My list", pool, true);
      showEmpty(!pool.length, state.list.length ? "Nothing in your list matches that search." : "Your list is empty. Open any title and choose “Add to my list” to save it here.");
    } else if (state.query) {
      if (state.filter !== "all") pool = pool.filter(function (t) { return t.kind === state.filter; });
      renderHero(null);
      html = shelf("Results for “" + esc(state.query) + "”", pool, true);
      showEmpty(!pool.length, "No titles match “" + state.query + "”. Try a genre like drama or thriller.");
    } else if (state.filter === "all") {
      renderHomeHero();
      html = shelf("Trending this week", pool.slice().sort(byRating).slice(0, 10)) +
             shelf("New releases", pool.filter(function (t) { return t.year >= 2025; }).sort(byYear)) +
             shelf("Movies", pool.filter(function (t) { return t.kind === "movie"; }).sort(byYear)) +
             shelf("Series to binge", pool.filter(function (t) { return t.kind === "series"; }).sort(byRating));
      showEmpty(false);
    } else {
      var kindItems = pool.filter(function (t) { return t.kind === state.filter; });
      renderHero(kindItems.slice().sort(byRating)[0]);
      var genres = {};
      kindItems.forEach(function (t) { t.genres.forEach(function (g) { (genres[g] = genres[g] || []).push(t); }); });
      html = shelf("All " + (state.filter === "movie" ? "movies" : "series"), kindItems.slice().sort(byYear)) +
             Object.keys(genres).filter(function (g) { return genres[g].length > 1; }).sort()
               .map(function (g) { return shelf(g, genres[g].sort(byRating)); }).join("");
      showEmpty(false);
    }
    $("shelves").innerHTML = html;
  }

  function showEmpty(on, msg) { $("empty").hidden = !on; if (on) $("empty").textContent = msg; }

  var toastTimer;
  function toast(msg) {
    var el = $("toast"); el.textContent = msg; el.classList.add("show");
    clearTimeout(toastTimer); toastTimer = setTimeout(function () { el.classList.remove("show"); }, 2200);
  }

  function inList(id) { return state.list.indexOf(id) !== -1; }

  function openDetail(id) {
    var t = TITLES.filter(function (x) { return x.id === id; })[0];
    if (!t) return;
    state.current = t;
    $("detail-art").innerHTML = poster(t, true);
    $("detail-title").textContent = t.title;
    $("detail-facts").textContent = facts(t);
    $("detail-plot").textContent = t.plot;
    $("detail-list").textContent = inList(t.id) ? "Remove from my list" : "Add to my list";
    var d = $("detail");
    if (typeof d.showModal === "function") d.showModal(); else d.setAttribute("open", "");
  }

  function closeDetail() { var d = $("detail"); if (d.close) d.close(); else d.removeAttribute("open"); }

  // Events
  document.addEventListener("click", function (e) {
    var play = e.target.closest("[data-play]");
    if (play) { toast("Trailer playback is a demo — connect a video source to enable it."); return; }
    var c = e.target.closest("[data-id]");
    if (c) openDetail(Number(c.getAttribute("data-id")));
  });

  function setFilter(f) {
    document.querySelectorAll(".tabs button").forEach(function (x) { x.setAttribute("aria-selected", x.getAttribute("data-filter") === f ? "true" : "false"); });
    state.filter = f;
    render(); window.scrollTo({ top: 0 });
  }
  document.querySelectorAll(".tabs button").forEach(function (b) {
    b.addEventListener("click", function () { setFilter(b.getAttribute("data-filter")); });
  });
  document.addEventListener("click", function (e) {
    var g = e.target.closest("[data-goto]");
    if (g) setFilter(g.getAttribute("data-goto"));
  });
  document.querySelector(".brand").addEventListener("click", function (e) { e.preventDefault(); setFilter("all"); });

  var debounce;
  $("search").addEventListener("input", function (e) {
    clearTimeout(debounce);
    var v = e.target.value.trim().toLowerCase();
    debounce = setTimeout(function () { state.query = v; render(); }, 150);
  });

  $("detail-close").addEventListener("click", closeDetail);
  $("detail").addEventListener("click", function (e) { if (e.target === this) closeDetail(); });
  $("detail-play").addEventListener("click", function () { toast("Trailer playback is a demo — connect a video source to enable it."); });
  $("detail-list").addEventListener("click", function () {
    var t = state.current, btn = this; if (!t) return;
    var removing = inList(t.id), before = state.list.slice();
    state.list = removing ? state.list.filter(function (i) { return i !== t.id; }) : state.list.concat([t.id]);
    store.set(state.list);
    btn.textContent = inList(t.id) ? "Remove from my list" : "Add to my list";
    toast(removing ? "Removed from my list" : "Added to my list");
    if (state.filter === "list") render();
    if (state.source === "api") {
      api(removing ? "DELETE" : "PUT", "/api/watchlist/" + t.id).catch(function () {
        state.list = before; store.set(before);
        btn.textContent = inList(t.id) ? "Remove from my list" : "Add to my list";
        toast("Couldn't update my list: the backend didn't respond. Try again.");
        if (state.filter === "list") render();
      });
    }
  });

  $("host").textContent = "Served from " + window.location.host;
  render();
  connectBackend();
})();
