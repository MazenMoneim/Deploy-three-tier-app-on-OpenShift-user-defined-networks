// The site talks to the backend through its own nginx (/api is forwarded over the
// frontend-backend-net secondary network), so the API lives on the same origin.
window.PRIME_CONFIG = {
  apiUrl: window.location.origin
};
