/* Offline poster artwork: one illustrated SVG scene per title (no network needed). */
(function () {
  "use strict";
  function rng(seed) { var s = seed * 9301 + 49297; return function () { s = (s * 9301 + 49297) % 233280; return s / 233280; }; }
  function sky(id, top, bottom) {
    return '<defs><linearGradient id="sk' + id + '" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="' + top + '"/><stop offset="1" stop-color="' + bottom + '"/></linearGradient>' +
      '<radialGradient id="gl' + id + '"><stop offset="0" stop-color="#fff" stop-opacity=".9"/><stop offset=".25" stop-color="#ffd98a" stop-opacity=".6"/><stop offset="1" stop-color="#ffd98a" stop-opacity="0"/></radialGradient></defs>' +
      '<rect width="200" height="300" fill="url(#sk' + id + ')"/>';
  }
  function stars(r, n, maxY, op) {
    var s = ""; for (var i = 0; i < n; i++) s += '<circle cx="' + (r() * 200).toFixed(1) + '" cy="' + (r() * maxY).toFixed(1) + '" r="' + (r() * 1.1 + .3).toFixed(2) + '" fill="#fff" opacity="' + (op * (.4 + r() * .6)).toFixed(2) + '"/>';
    return s;
  }
  function windows(r, x, y, w, h, color, density) {
    var s = ""; for (var yy = y + 4; yy < y + h - 3; yy += 7) for (var xx = x + 3; xx < x + w - 3; xx += 6)
      if (r() < density) s += '<rect x="' + xx + '" y="' + yy + '" width="2.6" height="3.4" fill="' + color + '" opacity="' + (.5 + r() * .5).toFixed(2) + '"/>';
    return s;
  }
  function skyline(r, base, color, lit, density) {
    var s = "", x = -4;
    while (x < 204) { var w = 14 + r() * 22, h = 40 + r() * 90; s += '<rect x="' + x.toFixed(1) + '" y="' + (base - h).toFixed(1) + '" width="' + w.toFixed(1) + '" height="' + (h + 60) + '" fill="' + color + '"/>' + windows(r, x, base - h, w, h, lit, density); x += w + 1; }
    return s;
  }

  var scenes = {
    1: function (r) { // The Salt Road — desert caravan at dusk
      var camels = ""; for (var i = 0; i < 5; i++) { var x = 60 + i * 13; camels += '<path d="M' + x + ' 196 q3 -8 6 -1 q2 -6 5 0 l3 -5 l1 6 l-1 7 m-10 -7 l0 8 m8 -8 l0 8" stroke="#2a130c" stroke-width="1.6" fill="#2a130c"/>'; }
      return sky(1, "#f7b267", "#c2452d") + '<circle cx="130" cy="150" r="48" fill="#ffe3a3" opacity=".85"/>' +
        '<path d="M0 200 Q60 180 110 196 T200 188 V300 H0Z" fill="#b5532f"/>' + camels +
        '<path d="M0 225 Q70 205 130 228 T200 220 V300 H0Z" fill="#8c3a22"/><path d="M0 255 Q80 238 150 262 T200 256 V300 H0Z" fill="#5e2515"/>';
    },
    2: function (r) { // Harbor Lights — lighthouse & containers at night
      var boxes = "", cols = ["#c0392b", "#2e86c1", "#d68910", "#1e8449"];
      for (var i = 0; i < 9; i++) boxes += '<rect x="' + (8 + (i % 5) * 16) + '" y="' + (i < 5 ? 196 : 186) + '" width="15" height="9" fill="' + cols[i % 4] + '" opacity=".85"/>';
      var refl = ""; for (var j = 0; j < 14; j++) refl += '<rect x="' + (140 + r() * 30 - 15).toFixed(1) + '" y="' + (212 + j * 6) + '" width="' + (6 + r() * 16).toFixed(1) + '" height="1.5" fill="#ffe7a8" opacity=".5"/>';
      return sky(2, "#0b1d3a", "#1d4e89") + stars(r, 40, 150, 1) +
        '<polygon points="148,108 200,70 200,120" fill="#ffe7a8" opacity=".22"/><polygon points="148,108 90,78 96,112" fill="#ffe7a8" opacity=".14"/>' +
        '<polygon points="140,205 144,112 152,112 156,205" fill="#e8e1d4"/><rect x="142" y="140" width="12" height="8" fill="#b83a2f"/><rect x="142" y="170" width="12" height="8" fill="#b83a2f"/>' +
        '<rect x="141" y="100" width="14" height="12" fill="#ffe7a8"/><path d="M139 100 L148 91 L157 100Z" fill="#2c3e50"/>' +
        '<path d="M60 150 L64 150 L64 205 M40 150 L100 150 M90 150 L90 175" stroke="#0e2442" stroke-width="3" fill="none"/>' + boxes +
        '<rect y="205" width="200" height="95" fill="#0a1a33"/>' + refl;
    },
    3: function (r) { // Paper Moons — paper crescents on strings
      var s = "";
      [[40, 70, 20], [100, 120, 30], [160, 60, 18], [70, 190, 16], [145, 185, 24]].forEach(function (m, i) {
        s += '<line x1="' + m[0] + '" y1="0" x2="' + m[0] + '" y2="' + (m[1] - m[2]) + '" stroke="#fff" stroke-width=".6" opacity=".7"/>' +
          '<circle cx="' + m[0] + '" cy="' + m[1] + '" r="' + m[2] + '" fill="#fff4e0"/><circle cx="' + (m[0] + m[2] * .45) + '" cy="' + (m[1] - m[2] * .2) + '" r="' + (m[2] * .9) + '" fill="' + (i % 2 ? "#e56b8a" : "#d95479") + '"/>';
      });
      return sky(3, "#f28ca5", "#c93f64") + s + '<rect y="240" width="200" height="60" fill="#8e2447" opacity=".6"/>';
    },
    4: function (r) { // Station Nine — orbital station over a planet
      return sky(4, "#020814", "#0d2a3a") + stars(r, 90, 300, 1) +
        '<circle cx="100" cy="420" r="210" fill="#1b6b73"/><circle cx="100" cy="420" r="210" fill="none" stroke="#7ee0d6" stroke-width="3" opacity=".6"/>' +
        '<g transform="translate(100 120) rotate(-18)"><ellipse rx="52" ry="14" fill="none" stroke="#cfd8dc" stroke-width="5"/><rect x="-6" y="-34" width="12" height="68" fill="#90a4ae"/>' +
        '<rect x="-40" y="-4" width="80" height="8" fill="#b0bec5"/><rect x="-78" y="-10" width="30" height="20" fill="#3d6ea8"/><rect x="48" y="-10" width="30" height="20" fill="#3d6ea8"/>' +
        '<circle r="9" fill="#eceff1"/><circle r="3" fill="#ff5252"/></g>';
    },
    5: function (r) { // Quiet Engines — empty road into a sunset
      var d = ""; for (var i = 0; i < 6; i++) { var y = 200 + i * i * 3 + i * 6, w = 1 + i * 1.2; d += '<rect x="' + (100 - w / 2) + '" y="' + y + '" width="' + w + '" height="' + (3 + i * 2) + '" fill="#f7dc6f"/>'; }
      return sky(5, "#f39c4a", "#8e2d1e") + '<circle cx="100" cy="190" r="40" fill="#ffd27a"/>' +
        '<path d="M0 195 L30 175 L55 190 L85 168 L120 192 L160 172 L200 190 V300 H0Z" fill="#5a2418"/>' +
        '<polygon points="92,195 108,195 200,300 0,300" fill="#2b2b2b"/>' + d +
        '<g transform="translate(118 262)"><rect x="-22" y="-10" width="44" height="12" rx="3" fill="#9b1d20"/><path d="M-14 -10 L-8 -19 L10 -19 L16 -10Z" fill="#9b1d20"/><circle cx="-12" cy="3" r="5" fill="#111"/><circle cx="12" cy="3" r="5" fill="#111"/></g>';
    },
    6: function (r) { // The Long Shift — hospital in a city at night
      return sky(6, "#08221f", "#1c5c52") + stars(r, 25, 120, .8) + skyline(r, 230, "#0c2d29", "#9fe8d8", .35) +
        '<rect x="60" y="120" width="80" height="180" fill="#123f39"/>' + windows(r, 60, 140, 80, 150, "#fff3c4", .7) +
        '<rect x="88" y="98" width="24" height="24" fill="#fff"/><rect x="97" y="102" width="6" height="16" fill="#e74c3c"/><rect x="92" y="107" width="16" height="6" fill="#e74c3c"/>';
    },
    7: function (r) { // Glass Orchard — trees with glowing clear fruit
      var s = "";
      for (var row = 0; row < 3; row++) for (var i = 0; i < 4 - (row === 0 ? 0 : 1); i++) {
        var x = 30 + i * 50 + (row % 2) * 25, y = 150 + row * 45, k = 1 - row * .12;
        s += '<rect x="' + (x - 2) + '" y="' + y + '" width="4" height="' + (40 * k) + '" fill="#1d1026"/><circle cx="' + x + '" cy="' + (y - 5) + '" r="' + (24 * k) + '" fill="#2c1a3d"/>';
        for (var f = 0; f < 4; f++) s += '<circle cx="' + (x + (r() - .5) * 30 * k).toFixed(1) + '" cy="' + (y - 5 + (r() - .5) * 26 * k).toFixed(1) + '" r="2.8" fill="#d6fff0" opacity=".85"/>';
      }
      return sky(7, "#3b1f5a", "#6a8f3a") + '<circle cx="150" cy="70" r="24" fill="#e8ffd9" opacity=".6"/>' + s;
    },
    8: function (r) { // Northbound — aurora over snowy peaks
      return sky(8, "#051833", "#0f4d4a") + stars(r, 60, 180, 1) +
        '<path d="M-10 90 C40 60 80 130 130 80 S190 70 210 60" stroke="#6effb4" stroke-width="16" fill="none" opacity=".35"/>' +
        '<path d="M-10 120 C50 90 90 150 140 105 S190 110 210 90" stroke="#58d6ff" stroke-width="10" fill="none" opacity=".3"/>' +
        '<path d="M0 230 L45 150 L75 195 L115 130 L160 200 L200 160 V300 H0Z" fill="#dbe8f0"/>' +
        '<path d="M0 230 L45 150 L55 168 L40 175 L30 200Z M115 130 L128 152 L112 150 L100 158Z" fill="#fff"/>' +
        '<path d="M0 250 L60 205 L120 245 L200 215 V300 H0Z" fill="#8fa9bd"/>';
    },
    9: function (r) { // Last Call at Zamalek — bridge and river lights
      var arches = ""; for (var i = 0; i < 5; i++) arches += '<path d="M' + (i * 44 - 4) + ' 212 Q' + (i * 44 + 18) + ' 190 ' + (i * 44 + 40) + ' 212" stroke="#f5c26b" stroke-width="2" fill="none"/>';
      var refl = ""; for (var j = 0; j < 20; j++) refl += '<rect x="' + (r() * 190).toFixed(1) + '" y="' + (222 + r() * 70).toFixed(1) + '" width="' + (4 + r() * 12).toFixed(1) + '" height="1.4" fill="#f5c26b" opacity=".45"/>';
      return sky(9, "#1a0b2e", "#5b2a6e") + '<circle cx="150" cy="60" r="14" fill="#f6e6c8"/>' + skyline(r, 190, "#22112f", "#f5c26b", .3) +
        '<rect y="186" width="200" height="6" fill="#140a1e"/>' + arches + '<rect y="212" width="200" height="88" fill="#120822"/>' + refl +
        '<g transform="translate(40 262)"><path d="M-10 -14 L10 -14 L0 -2Z" fill="#fff" opacity=".85"/><rect x="-.6" y="-2" width="1.2" height="10" fill="#fff"/><rect x="-5" y="8" width="10" height="1.4" fill="#fff"/></g>';
    },
    10: function (r) { // Small Kingdoms — bakery storefront
      var aw = ""; for (var i = 0; i < 8; i++) aw += '<path d="M' + (20 + i * 20) + ' 120 h20 v24 q-10 8 -20 0Z" fill="' + (i % 2 ? "#fff6dc" : "#c0392b") + '"/>';
      var bread = ""; for (var k = 0; k < 5; k++) bread += '<ellipse cx="' + (52 + k * 24) + '" cy="200" rx="10" ry="6" fill="#d4913a"/><path d="M' + (46 + k * 24) + ' 199 l4 -3 m3 3 l4 -3" stroke="#8a5220" stroke-width="1"/>';
      return sky(10, "#f6d365", "#9a7b1f") + '<rect x="20" y="100" width="160" height="200" fill="#6e3b1f"/>' +
        '<rect x="20" y="100" width="160" height="20" fill="#4a2512"/><text x="100" y="114" text-anchor="middle" font-size="10" fill="#f6d365" font-family="Georgia,serif">BAKERY</text>' + aw +
        '<rect x="36" y="160" width="128" height="56" fill="#ffe8b0"/><rect x="36" y="206" width="128" height="10" fill="#b07a3c"/>' + bread +
        '<rect x="84" y="230" width="32" height="70" fill="#3b1e0e"/><rect x="0" y="290" width="200" height="10" fill="#3d2a14"/>';
    },
    11: function (r) { // Undertow — underwater, a case on the seabed
      var rays = ""; for (var i = 0; i < 5; i++) rays += '<polygon points="' + (30 + i * 35) + ',0 ' + (45 + i * 35) + ',0 ' + (70 + i * 30) + ',300 ' + (50 + i * 30) + ',300" fill="#bff3ff" opacity=".07"/>';
      var bubbles = ""; for (var j = 0; j < 18; j++) bubbles += '<circle cx="' + (110 + r() * 30).toFixed(1) + '" cy="' + (40 + r() * 110).toFixed(1) + '" r="' + (1 + r() * 2.5).toFixed(1) + '" fill="none" stroke="#dff9ff" stroke-width=".7" opacity=".7"/>';
      return sky(11, "#1a8fb3", "#04213a") + rays + bubbles +
        '<g transform="translate(118 165) rotate(20)"><ellipse rx="7" ry="22" fill="#061a2b"/><circle cy="-26" r="6" fill="#061a2b"/><path d="M-4 20 L-10 42 L-2 40Z M4 20 L10 42 L2 40Z" fill="#061a2b"/></g>' +
        '<path d="M0 262 Q50 248 100 260 T200 255 V300 H0Z" fill="#c9b27a" opacity=".55"/><rect x="72" y="248" width="30" height="18" rx="2" fill="#b0b8bf"/><rect x="84" y="244" width="6" height="4" fill="#b0b8bf"/>';
    },
    12: function (r) { // Kingdom of Ash — volcano over a castle
      var ash = ""; for (var i = 0; i < 40; i++) ash += '<circle cx="' + (r() * 200).toFixed(1) + '" cy="' + (r() * 200).toFixed(1) + '" r="' + (r() * 1.4 + .4).toFixed(1) + '" fill="#ffb27a" opacity="' + (.3 + r() * .6).toFixed(2) + '"/>';
      return sky(12, "#2a0a06", "#a3321a") + '<circle cx="100" cy="95" r="70" fill="url(#gl12)" opacity=".5"/>' +
        '<path d="M90 95 C70 60 110 50 95 20 C130 40 120 70 110 95Z" fill="#3a2a2a" opacity=".8"/>' + ash +
        '<path d="M20 230 L85 100 L115 100 L180 230Z" fill="#1c0b08"/><path d="M85 100 L115 100 L108 118 L100 110 L92 122Z" fill="#ff6a2b"/>' +
        '<path d="M40 300 V240 h8 v-8 h6 v8 h8 v-20 h10 v-10 h6 v10 h10 v20 h8 v-8 h6 v8 h8 v-30 h14 v30 h8 V300Z" fill="#0e0504"/>';
    },
    13: function (r) { // Signal & Noise — radio tower broadcasting
      var arcs = ""; for (var i = 1; i < 5; i++) arcs += '<path d="M' + (100 - i * 18) + ' ' + (70 - i * 4) + ' A' + (i * 20) + ' ' + (i * 20) + ' 0 0 1 ' + (100 + i * 18) + ' ' + (70 - i * 4) + '" stroke="#f0a8ff" stroke-width="2" fill="none" opacity="' + (1 - i * .18) + '"/>';
      var lat = ""; for (var y = 90; y < 260; y += 16) { var w = (y - 70) * .22; lat += '<path d="M' + (100 - w) + ' ' + y + ' L' + (100 + w + 3.5) + ' ' + (y + 16) + ' M' + (100 + w) + ' ' + y + ' L' + (100 - w - 3.5) + ' ' + (y + 16) + '" stroke="#1a0d24" stroke-width="1.4"/>'; }
      return sky(13, "#12081f", "#6d2e8c") + stars(r, 50, 200, .9) + arcs +
        '<path d="M100 70 L140 300 H60Z" fill="none" stroke="#1a0d24" stroke-width="3"/>' + lat + '<circle cx="100" cy="68" r="4" fill="#ff4d6d"/>' +
        '<path d="M0 270 Q100 250 200 270 V300 H0Z" fill="#1a0d24"/>';
    },
    14: function (r) { // The Understudy — spotlight on an empty stage
      var folds = ""; for (var i = 0; i < 6; i++) folds += '<rect x="' + (i * 7) + '" y="0" width="3" height="300" fill="#000" opacity=".18"/><rect x="' + (158 + i * 7) + '" y="0" width="3" height="300" fill="#000" opacity=".18"/>';
      return sky(14, "#2a0712", "#120307") + '<polygon points="85,0 115,0 160,250 40,250" fill="#fff3d6" opacity=".16"/>' +
        '<ellipse cx="100" cy="252" rx="62" ry="12" fill="#fff3d6" opacity=".35"/>' +
        '<g fill="#140306"><circle cx="100" cy="194" r="8"/><path d="M92 204 Q100 200 108 204 L114 250 H86Z"/></g>' +
        '<path d="M0 0 H45 Q30 150 42 300 H0Z" fill="#9e1b32"/><path d="M200 0 H155 Q170 150 158 300 H200Z" fill="#9e1b32"/>' + folds +
        '<path d="M0 0 H200 V24 Q150 40 100 26 Q50 40 0 24Z" fill="#7a1024"/><rect y="258" width="200" height="42" fill="#3b1a0f"/>';
    },
    15: function (r) { // Dead Reckoning — ship in fog, compass overlay
      var ticks = ""; for (var i = 0; i < 16; i++) { var a = i * Math.PI / 8, l = i % 4 ? 8 : 18; ticks += '<line x1="' + (100 + Math.cos(a) * 60).toFixed(1) + '" y1="' + (110 + Math.sin(a) * 60).toFixed(1) + '" x2="' + (100 + Math.cos(a) * (60 - l)).toFixed(1) + '" y2="' + (110 + Math.sin(a) * (60 - l)).toFixed(1) + '" stroke="#e8f0f6" stroke-width="1.2" opacity=".5"/>'; }
      var waves = ""; for (var w = 0; w < 7; w++) waves += '<path d="M0 ' + (220 + w * 12) + ' q12 -5 25 0 t25 0 t25 0 t25 0 t25 0 t25 0 t25 0 t25 0" stroke="#9fb6c8" stroke-width="1.2" fill="none" opacity="' + (.5 - w * .05) + '"/>';
      return sky(15, "#2b3f5c", "#6f8aa3") + '<circle cx="100" cy="110" r="60" fill="none" stroke="#e8f0f6" stroke-width="1.5" opacity=".5"/>' + ticks +
        '<polygon points="100,50 106,110 100,170 94,110" fill="#e8f0f6" opacity=".35"/>' +
        '<g fill="#101c2c"><path d="M50 210 H150 L138 226 H62Z"/><rect x="98" y="150" width="3" height="60"/><path d="M102 155 L132 200 H102Z" opacity=".8"/><path d="M97 160 L72 200 H97Z" opacity=".8"/></g>' +
        '<rect y="224" width="200" height="76" fill="#1e3148"/>' + waves + '<rect y="190" width="200" height="30" fill="#c9d6e0" opacity=".18"/>';
    },
    16: function (r) { // Wildflower Season — spring meadow
      var fl = "", cols = ["#ff7eb6", "#fff27a", "#ffffff", "#c89bff", "#ff9f6e"];
      for (var i = 0; i < 90; i++) { var y = 200 + r() * 100, x = r() * 200, sz = .8 + (y - 200) / 40; fl += '<circle cx="' + x.toFixed(1) + '" cy="' + y.toFixed(1) + '" r="' + sz.toFixed(1) + '" fill="' + cols[i % 5] + '"/>'; }
      return sky(16, "#b8e0ff", "#f7c6d9") + '<circle cx="150" cy="80" r="20" fill="#fffbe6"/>' +
        '<path d="M0 190 Q60 160 120 185 T200 175 V300 H0Z" fill="#7fb46b"/><path d="M0 215 Q80 195 140 215 T200 208 V300 H0Z" fill="#4f8a45"/>' + fl;
    }
  };

  window.posterArt = function (t) {
    var scene = scenes[t.id];
    var body = scene ? scene(rng(t.id)) : '<rect width="200" height="300" fill="hsl(' + t.hues[0] + ' 50% 30%)"/>';
    return '<svg class="p-art" viewBox="0 0 200 300" preserveAspectRatio="xMidYMid slice" aria-hidden="true">' + body + "</svg>";
  };
})();
