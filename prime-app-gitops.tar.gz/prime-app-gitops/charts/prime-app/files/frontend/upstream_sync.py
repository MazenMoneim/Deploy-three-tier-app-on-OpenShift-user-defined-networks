#!/usr/bin/env python3
"""upstream-sync: keep the frontend's nginx pointed at the backend pods.

The backend is reached over a secondary network (frontend-backend-net), whose pod IPs
are not behind any Service. This watches the backend pods through the Kubernetes API,
writes their secondary-network IPs into an nginx upstream file, and reloads nginx when
the list changes.

  python3 upstream_sync.py --once   # init container: write the file once, then exit
  python3 upstream_sync.py          # sidecar: keep it in sync

Standard library only. Needs get/list on pods in the backend namespace.
"""
import json
import os
import signal
import ssl
import sys
import time
import urllib.parse
import urllib.request

SA_DIR = "/var/run/secrets/kubernetes.io/serviceaccount"
API = os.environ.get("KUBE_API", "https://kubernetes.default.svc")
NAMESPACE = os.environ.get("BACKEND_NAMESPACE", "webapp-backend")
SELECTOR = os.environ.get("BACKEND_SELECTOR", "app=backend-api")
NETWORK = os.environ.get("NETWORK_NAME", "frontend-backend-net")
PORT = os.environ.get("BACKEND_PORT", "8080")
OUT = os.environ.get("UPSTREAM_FILE", "/etc/nginx/prime/upstream.conf")
PID_FILE = os.environ.get("NGINX_PID_FILE", "/etc/nginx/prime/nginx.pid")
INTERVAL = int(os.environ.get("INTERVAL", "10"))


def log(msg):
    print(time.strftime("%Y-%m-%dT%H:%M:%S"), msg, flush=True)


def list_pods():
    url = f"{API}/api/v1/namespaces/{NAMESPACE}/pods?" + urllib.parse.urlencode({"labelSelector": SELECTOR})
    headers = {"Accept": "application/json"}
    token_file = os.path.join(SA_DIR, "token")
    if os.path.exists(token_file):  # re-read every time: the token is rotated
        with open(token_file) as f:
            headers["Authorization"] = "Bearer " + f.read().strip()
    ctx = None
    if url.startswith("https"):
        ca = os.path.join(SA_DIR, "ca.crt")
        ctx = ssl.create_default_context(cafile=ca if os.path.exists(ca) else None)
    with urllib.request.urlopen(urllib.request.Request(url, headers=headers), timeout=10, context=ctx) as r:
        return json.load(r).get("items", [])


def backend_ips(pods):
    ips = set()
    for pod in pods:
        meta, status = pod.get("metadata", {}), pod.get("status", {})
        if meta.get("deletionTimestamp") or status.get("phase") != "Running":
            continue
        ready = any(c.get("type") == "Ready" and c.get("status") == "True" for c in status.get("conditions", []))
        if not ready:
            continue
        nets = json.loads(meta.get("annotations", {}).get("k8s.v1.cni.cncf.io/network-status", "[]"))
        for net in nets:
            if net.get("name", "").endswith("/" + NETWORK):
                ips.update(ip.split("/")[0] for ip in net.get("ips", []))
    return sorted(ips)


def render(ips):
    lines = ["# Written by upstream-sync - do not edit", "upstream backend_api {"]
    if ips:
        lines += [f"  server {ip}:{PORT} max_fails=2 fail_timeout=10s;" for ip in ips]
    else:
        lines += ["  # no ready backend pods yet: fail fast so the site falls back to its built-in catalogue",
                  "  server 127.0.0.1:9;"]
    return "\n".join(lines + ["}", ""])


def write_if_changed(text):
    try:
        with open(OUT) as f:
            if f.read() == text:
                return False
    except FileNotFoundError:
        pass
    tmp = OUT + ".tmp"
    with open(tmp, "w") as f:
        f.write(text)
    os.replace(tmp, OUT)
    return True


def reload_nginx():
    try:
        with open(PID_FILE) as f:
            pid = int(f.read().strip())
        os.kill(pid, signal.SIGHUP)
        log(f"reloaded nginx (pid {pid})")
    except (FileNotFoundError, ValueError):
        log("nginx not running yet; it will read the file when it starts")
    except ProcessLookupError:
        log("nginx pid file is stale; will retry")


def sync():
    ips = backend_ips(list_pods())
    if write_if_changed(render(ips)):
        log(f"backend upstream -> {', '.join(ips) if ips else 'none ready'}")
        return True
    return False


def main():
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    if "--once" in sys.argv:
        try:
            sync()
        except Exception as e:  # never block the pod from starting
            log(f"initial sync failed ({e}); writing a placeholder")
            write_if_changed(render([]))
        return
    signal.signal(signal.SIGTERM, lambda *_: sys.exit(0))
    log(f"watching pods '{SELECTOR}' in {NAMESPACE} on network {NETWORK} every {INTERVAL}s")
    while True:
        try:
            if sync():
                reload_nginx()
        except Exception as e:
            log(f"sync failed: {e}")
        time.sleep(INTERVAL)


if __name__ == "__main__":
    main()
