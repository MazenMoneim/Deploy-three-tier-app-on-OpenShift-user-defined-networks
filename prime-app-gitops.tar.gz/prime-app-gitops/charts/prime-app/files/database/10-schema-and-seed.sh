# Sourced by the MariaDB image while it starts (every start), connected as root via $mysql_flags.
# Everything here is idempotent: tables are created once, seed rows only added if missing.
mysql $mysql_flags "$MYSQL_DATABASE" <<'SQL'
CREATE TABLE IF NOT EXISTS titles (
  id          INT UNSIGNED  NOT NULL PRIMARY KEY,
  kind        ENUM('movie','series') NOT NULL,
  title       VARCHAR(200)  NOT NULL,
  year        SMALLINT      NOT NULL,
  rating      DECIMAL(3,1)  NOT NULL DEFAULT 0.0,
  minutes     SMALLINT      NULL COMMENT 'movies only',
  seasons     TINYINT       NULL COMMENT 'series only',
  genres      VARCHAR(200)  NOT NULL COMMENT 'comma-separated',
  plot        TEXT          NOT NULL,
  created_at  TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at  TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  KEY idx_kind (kind),
  KEY idx_year (year)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS watchlist (
  viewer_id   VARCHAR(64)   NOT NULL,
  title_id    INT UNSIGNED  NOT NULL,
  added_at    TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (viewer_id, title_id),
  CONSTRAINT fk_watchlist_title FOREIGN KEY (title_id) REFERENCES titles (id) ON DELETE CASCADE
) ENGINE=InnoDB;

INSERT IGNORE INTO titles (id, kind, title, year, rating, minutes, seasons, genres, plot) VALUES
  (1, 'movie', 'The Salt Road', 2025, 8.4, 132, NULL, 'Drama,Adventure', 'A caravan guide agrees to one last crossing of the Western Desert, carrying a passenger who is not what she claims.'),
  (2, 'series', 'Harbor Lights', 2024, 8.9, NULL, 3, 'Crime,Thriller', 'A port inspector in Alexandria follows a missing shipping container into a network that reaches the top of the city.'),
  (3, 'movie', 'Paper Moons', 2023, 7.6, 104, NULL, 'Romance,Comedy', 'Two rival stationery shop owners discover they have been writing to each other anonymously for a year.'),
  (4, 'series', 'Station Nine', 2025, 8.2, NULL, 2, 'Sci-Fi,Mystery', 'The crew of a remote research station wakes up to find six months missing from every log.'),
  (5, 'movie', 'Quiet Engines', 2022, 7.9, 118, NULL, 'Drama', 'A retired rally driver teaches his estranged granddaughter to drive across the Delta in a borrowed car.'),
  (6, 'series', 'The Long Shift', 2023, 8.6, NULL, 4, 'Drama,Medical', 'Night-shift doctors at a crowded Cairo hospital hold their lives together between emergencies.'),
  (7, 'movie', 'Glass Orchard', 2024, 7.2, 97, NULL, 'Horror', 'A family inherits an orchard where the fruit grows clear, and anyone who eats it remembers something they shouldn\'t.'),
  (8, 'series', 'Northbound', 2022, 7.8, NULL, 1, 'Adventure,Documentary', 'Six strangers attempt to travel from Aswan to the Arctic Circle without a single flight.'),
  (9, 'movie', 'Last Call at Zamalek', 2025, 8.1, 111, NULL, 'Crime,Drama', 'Over one night in a jazz bar, a bartender pieces together why every regular is lying to the police.'),
  (10, 'series', 'Small Kingdoms', 2025, 8.0, NULL, 2, 'Comedy', 'Three siblings take over their late father\'s failing neighborhood bakery and its very loyal, very strange customers.'),
  (11, 'movie', 'Undertow', 2021, 7.4, 125, NULL, 'Thriller', 'A free-diving instructor finds a sealed case on the Red Sea floor and becomes the only witness to a crime.'),
  (12, 'series', 'Kingdom of Ash', 2024, 9.1, NULL, 3, 'Fantasy,Drama', 'When the volcano that protects a mountain realm goes quiet, five houses race to claim what comes next.'),
  (13, 'movie', 'Signal & Noise', 2025, 7.7, 101, NULL, 'Sci-Fi,Thriller', 'A network engineer notices one tower broadcasting a message nobody sent - and it\'s addressed to her.'),
  (14, 'movie', 'The Understudy', 2023, 8.3, 115, NULL, 'Drama,Music', 'An opera understudy gets one night on stage and a single chance to prove the star was never irreplaceable.'),
  (15, 'series', 'Dead Reckoning', 2021, 8.4, NULL, 5, 'Crime,Mystery', 'A navigator-turned-detective solves cases at sea where every suspect is on board and nobody can leave.'),
  (16, 'series', 'Wildflower Season', 2025, 7.5, NULL, 1, 'Romance,Drama', 'A florist returns to her hometown for one spring and finds everything, and everyone, has moved on but her.');
SQL
